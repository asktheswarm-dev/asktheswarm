<?php
// pages/tag.php
$tag = $GLOBALS['route_params'][0] ?? '';
$rows = fetch_question_cards(
    'q.id IN (SELECT question_id FROM question_tags qt JOIN tags t ON t.id=qt.tag_id WHERE t.name=?)',
    [$tag], 50);
page_head("Tag: $tag");
?>
<h1><span class="tag-chip big"><?= h($tag) ?></span></h1>
<?php if (!$rows): ?><div class="empty"><p>No questions tagged <?= h($tag) ?> yet.</p></div><?php endif; ?>
<?php foreach ($rows as $q) question_card($q); ?>
<?php page_foot();