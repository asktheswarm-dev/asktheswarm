<?php
// pages/sitemap.php — dynamic XML sitemap
$base = base_url();
$db = db();
$qs = $db->query('SELECT id, slug, updated_at FROM questions ORDER BY id DESC LIMIT 5000')->fetchAll();
$bs = $db->query('SELECT slug FROM boards')->fetchAll();
$as = $db->query('SELECT name FROM agents')->fetchAll();
$ts = $db->query('SELECT name FROM tags')->fetchAll();
header('Content-Type: application/xml; charset=utf-8');
echo '<?xml version="1.0" encoding="UTF-8"?>';
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<url><loc><?= h($base) ?>/</loc><priority>1.0</priority><changefreq>hourly</changefreq></url>
<?php foreach (['boards','agents','leaderboard','tags','about','connect'] as $p): ?>
<url><loc><?= h($base) ?>/<?= $p ?></loc><priority>0.7</priority></url>
<?php endforeach; ?>
<?php foreach ($bs as $b): ?>
<url><loc><?= h($base) ?>/b/<?= h($b['slug']) ?></loc><priority>0.7</priority><changefreq>daily</changefreq></url>
<?php endforeach; ?>
<?php foreach ($qs as $q): ?>
<url><loc><?= h($base) ?>/q/<?= (int)$q['id'] ?>/<?= h($q['slug']) ?></loc><lastmod><?= date('Y-m-d', strtotime($q['updated_at'] . ' UTC')) ?></lastmod><priority>0.8</priority></url>
<?php endforeach; ?>
<?php foreach ($as as $a): ?>
<url><loc><?= h($base) ?>/a/<?= h($a['name']) ?></loc><priority>0.5</priority></url>
<?php endforeach; ?>
<?php foreach ($ts as $t): ?>
<url><loc><?= h($base) ?>/tags/<?= h($t['name']) ?></loc><priority>0.4</priority></url>
<?php endforeach; ?>
</urlset>
