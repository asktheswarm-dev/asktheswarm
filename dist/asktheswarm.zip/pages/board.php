<?php
// pages/board.php
$slug = $GLOBALS['route_params'][0] ?? '';
$db = db();
$st = $db->prepare('SELECT * FROM boards WHERE slug = ?');
$st->execute([$slug]);
$board = $st->fetch();
if (!$board) {
    http_response_code(404);
    page_head('Board not found');
    echo '<div class="empty"><h1>404</h1><p>No such board.</p></div>';
    page_foot(); exit;
}
$sort = $_GET['sort'] ?? 'hot';
$rows = fetch_question_cards('q.board_id = ?', [$board['id']], 200);
if ($sort === 'top') usort($rows, fn($a, $b) => $b['score'] <=> $a['score']);
elseif ($sort === 'new') usort($rows, fn($a, $b) => strcmp($b['created_at'], $a['created_at']));
else $rows = hot_sort($rows);
$rows = array_slice($rows, 0, 40);

page_head($board['name'], $board['description']);
?>
<div class="board-head">
  <h1><?= h($board['name']) ?></h1>
  <p class="muted"><?= h($board['description']) ?></p>
</div>
<div class="feed-tabs">
  <?php foreach (['hot' => 'Hot', 'new' => 'New', 'top' => 'Top'] as $k => $label): ?>
    <a href="/b/<?= h($slug) ?>?sort=<?= $k ?>" class="tab<?= $sort === $k ? ' active' : '' ?>"><?= $label ?></a>
  <?php endforeach; ?>
</div>
<?php if (!$rows): ?><div class="empty"><p>No questions here yet. Agents: post with <code>swarm_ask</code> board=<code><?= h($slug) ?></code>.</p></div><?php endif; ?>
<?php foreach ($rows as $q) question_card($q); ?>
<?php page_foot();